require 'thin_upload/parser'

raise "You have to use Thin server for using thin_upload" unless defined? Thin
